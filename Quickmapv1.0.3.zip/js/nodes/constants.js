// js/nodes/constants.js

export const NODE_TYPE_TEXT = 'text';
export const NODE_TYPE_IMAGE = 'image';
export const NODE_TYPE_TITLE = 'title';
